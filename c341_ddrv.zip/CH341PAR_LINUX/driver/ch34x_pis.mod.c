#include <linux/build-salt.h>
#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(.gnu.linkonce.this_module) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section(__versions) = {
	{ 0x3654b8c2, "module_layout" },
	{ 0x85ba342e, "usb_deregister" },
	{ 0x3a775fae, "usb_register_driver" },
	{ 0xb2fd5ceb, "__put_user_4" },
	{ 0xc3aaf0a9, "__put_user_1" },
	{ 0x6729d3df, "__get_user_4" },
	{ 0xd79bdb10, "usb_control_msg" },
	{ 0x167e7f9d, "__get_user_1" },
	{ 0x7e1a3bc9, "usb_unanchor_urb" },
	{ 0x52a16aa0, "usb_submit_urb" },
	{ 0xfae750be, "usb_anchor_urb" },
	{ 0x2e60bace, "memcpy" },
	{ 0xd531850b, "usb_alloc_coherent" },
	{ 0xc2101ea9, "usb_free_urb" },
	{ 0x362ef408, "_copy_from_user" },
	{ 0xd7c6c067, "usb_alloc_urb" },
	{ 0x81b395b3, "down_interruptible" },
	{ 0x47941711, "_raw_spin_lock_irq" },
	{ 0xecc9cdd8, "printk" },
	{ 0x8f87e26d, "usb_deregister_dev" },
	{ 0xcb02c046, "usb_autopm_put_interface" },
	{ 0xdecd0b29, "__stack_chk_fail" },
	{ 0xf6c791dd, "usb_bulk_msg" },
	{ 0x2d6fcc06, "__kmalloc" },
	{ 0xb44ad4b3, "_copy_to_user" },
	{ 0x88db9f48, "__check_object_size" },
	{ 0x7d7a9797, "usb_find_interface" },
	{ 0x296695f, "refcount_warn_saturate" },
	{ 0x6d012197, "_dev_info" },
	{ 0x57873d61, "usb_register_dev" },
	{ 0xaffbb4f, "__mutex_init" },
	{ 0x9326d035, "usb_get_dev" },
	{ 0xd9a5ea54, "__init_waitqueue_head" },
	{ 0xf0df950a, "kmem_cache_alloc_trace" },
	{ 0xd9fe29ea, "kmalloc_caches" },
	{ 0x37a0cba, "kfree" },
	{ 0x1b2e3ea4, "usb_put_dev" },
	{ 0x1b58e04c, "mutex_lock" },
	{ 0x962c8ae1, "usb_kill_anchored_urbs" },
	{ 0x407af304, "usb_wait_anchor_empty_timeout" },
	{ 0xd7747fec, "_dev_err" },
	{ 0xcf2a6966, "up" },
	{ 0xc22c1bbe, "usb_free_coherent" },
	{ 0xd60c2042, "pv_ops" },
	{ 0xdbf17652, "_raw_spin_lock" },
	{ 0x99b76c81, "mutex_unlock" },
	{ 0xbdfb6dbb, "__fentry__" },
};

MODULE_INFO(depends, "");

MODULE_ALIAS("usb:v1A86p5512d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v1A86p55DBd*dc*dsc*dp*ic*isc*ip*in02*");
MODULE_ALIAS("usb:v1A86p55DDd*dc*dsc*dp*ic*isc*ip*in02*");

MODULE_INFO(srcversion, "693D35E4BF13261A2347EF2");
